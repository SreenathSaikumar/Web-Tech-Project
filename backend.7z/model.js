const mongoose=require("mongoose");
const Schema=mongoose.Schema;

let laptop=new Schema({
    productName:{
        type:String
    },
    image:{
        type:String
    },
    spec:{
        type:String
    },
    price:{
        type:Number
    },
    stock:{
        type:Number
    }

});
module.exports=mongoose.model("laptop",laptop);