const express = require('express');
const app = express();
const cors = require('cors');
const PORT = 4000;
const mongoose = require('mongoose');
app.use(cors());
let laptop = require("./model");

const router = express.Router();


mongoose.connect("mongodb://localhost:27017/mydb", { useNewUrlParser: true, useUnifiedTopology: true });

laptop.findOne({},function(err,docs){
    if(err){
        console.log(err)
    }else{
        console.log(docs)
    }
})
/*const connection = mongoose.connection;

connection.once("open", function () {
    console.log("Connection with Mongo was successful");
    console.log(connection.laptop.findOne({}));
});*/

app.use("/", router);
router.route("/getData").get(function (req, res) {
    laptop.find({}, function (err, result) {
        if (err) {
            res.send(err);
        } else {
            res.send(result);
        }
    });
});

app.listen(PORT, function () {
    console.log("Server is running on Port: " + PORT);
});
