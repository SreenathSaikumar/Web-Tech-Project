import React from 'react';
import withContext from '../withContext';

import OrderItem from './OrderItem';

const Order = props => {
    const { orders } = props.context;
    //const orderKeys=Object.keys(orders||{})
    return (
        <>
            <div className='hero is-primary'>
                <div className="hero-body container">
                    <h4 className='title'>My Orders</h4>
                </div>
            </div>
            <br />
            <div className='container'>
                <div className='column columns is-multiline'>
                    {orders && orders.length ? (
                        orders.map((product,index) => (
                            <OrderItem
                            product={product}
                                key={index}
                                addToCart={props.context.addToCart}
                            />
                        ))
                    ) : (
                            <div className='column'>
                                <span className='title has-text-grey-light'>
                                    No Orders
                        </span>
                            </div>
                        )}
                </div>
            </div>
        </>
    );
};

export default withContext(Order);