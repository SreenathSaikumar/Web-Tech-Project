const mongoose=require('mongoose');
const Schema=mongoose.Schema;
let item=new Schema({
    productName:{
        type:String
    },
    image:{
        type:String
    },
    spec:{
        type:String
    },
    price:{
        type:Number
    },
    stock:{
        type:Number
    }

});
let order=new Schema({
    username:{
        type:String
    },
    items:[item]
});
module.exports=mongoose.model("order",order);