const express = require('express');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const jwt_decode=require('jwt-decode');
const app = express();
const cors = require('cors');
const PORT = 4000;
const mongoose = require('mongoose');
app.use(bodyParser.json());
app.use(cors());
let item = require("./model");
let users = require("./usermodel");
let orders=require("./ordermodel");

const accessTokenSecret = 'youraccesstokensecret';

const router = express.Router();


mongoose.connect("mongodb://localhost:27017/newdb", { useNewUrlParser: true, useUnifiedTopology: true });

item.findOne({}, function (err, docs) {
    if (err) {
        console.log(err)
    } else {
        console.log(docs)
    }
})
users.findOne({},function(err,docs){
    if(err){
        console.log(err)
    }else{
        console.log(docs)
    }
})
/*const connection = mongoose.connection;

connection.once("open", function () {
    console.log("Connection with Mongo was successful");
    console.log(connection.laptop.findOne({}));
});*/

app.use("/", router);
router.route("/getData").get(function (req, res) {
    item.find({}, function (err, result) {
        if (err) {
            res.send(err);
        } else {
            res.send(result);
        }
    });
});
app.post('/login', (req, res) => {
    // Read username and password from request body
    const { username, password } = req.body;

    // Filter user from the users array by username and password
    const user = users.find({username:username,password:password},function(err,docs){
        if(err){
            console.log(err);
        }else{
            console.log(docs);
        }
    });

    if (user) {
        // Generate an access token
        const accessToken = jwt.sign({ username: user.username }, accessTokenSecret);

        res.status(200).json({
            accessToken
        });
        //res.sendStatus(200);
    } else {
        res.sendStatus(401);
    }
});
app.put('/products/:id',(req,res)=>{
    item.findByIdAndUpdate(req.params.id,req.body,{new:true},function(err,result){
        if(err){
            console.log(err);
        }else{
            console.log(result);
        }
    })
})
app.put('/orders/:name',(req,res)=>{
    orders.update({username:req.params.name},{username:req.params.name,$push:{items:req.body}},{upsert:true,new:true},function(err,result){
        if(err){
            console.log(err);
        }else{
            console.log(result);
        }
    })
})
app.get('/orders/:email',(req,res)=>{
    orders.find({username:req.params.email},{items:1},function(err,result){
        if(err){
            console.log(err);
        }else{
            res.send(result);
        }
    })
})
app.listen(PORT, function () {
    console.log("Server is running on Port: " + PORT);
});
