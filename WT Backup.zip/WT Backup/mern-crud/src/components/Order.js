import React from 'react';
import withContext from '../withContext';
import CartItem from './CartItem';
import ProductItem from './ProductItem';

const Order = props => {
    const { orders } = props.context;
    return (
        <>
            <div className='hero is-primary'>
                <div className="hero-body container">
                    <h4 className='title'>My Orders</h4>
                </div>
            </div>
            <br />
            <div className='container'>
                <div className='column columns is-multiline'>
                    {orders && orders.length ? (
                        orders.map((product, index) => (
                            <ProductItem
                                product={product}
                                key={index}
                                addToCart={props.context.addToCart}
                            />
                        ))
                    ) : (
                            <div className='column'>
                                <span className='title has-text-grey-light'>
                                    No Orders
                        </span>
                            </div>
                        )}
                </div>
            </div>
        </>
    );
};

export default withContext(Order);